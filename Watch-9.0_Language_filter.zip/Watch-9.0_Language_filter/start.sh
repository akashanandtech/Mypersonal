echo "Cloning Repo...."
git clone https://github.com/Your_Repo_Name /LazyDeveloper
cd /LazyDeveloper
pip3 install -r requirements.txt
echo "Starting Bot...."
python3 bot.py
